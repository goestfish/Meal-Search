5914 project

run main.py to open the web

need to pip flask, elasticsearch, request libraries
